import java.util.ArrayList;

public class RecordHandler {

	private ArrayList<Record> records;

	public RecordHandler() {

		records = new ArrayList<Record>();
	}
	
	public void listRecords() {

		System.out.println(" ");
		System.out.println("List of all records");
		System.out.println("--------------------------------------");

		Record temp;

		for (int i = 0; i < records.size(); i++) {

			temp = records.get(i);

			System.out.println("[" + (i + 1) + "] " + temp.grabName());

		}
	}

	public boolean exists(int i) {

		return (i <= records.size() && i > 0);
	}

	public Record viewRecord(int i) {

		return records.get(i - 1);
	}

	public int amount() {

		return records.size();

	}

	public void add(Record r) {

		records.add(r);
	}


	public void remove(int i) {

		records.remove(i - 1);

	}

	public Record[] grabRecords() {

		return records.toArray(new Record[records.size()]);

	}
}
