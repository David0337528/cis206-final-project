
import java.io.File;

import java.io.FileInputStream;

import java.io.FileOutputStream;

import java.io.IOException;

import java.io.ObjectInputStream;

import java.io.ObjectOutputStream;

import java.util.Scanner;

import java.util.InputMismatchException;

public class Menu {

	private Scanner in;

	private RecordHandler records;
	
	public Menu() {

		this.in = new Scanner(System.in);

		this.records = new RecordHandler();
	}

	private void printMenu() {

		System.out.println("Please enter in an option:");

		System.out.println("1. Show list of all records");

		System.out.println("2. View record ID's");

		System.out.println("3. Add a record to list");

		System.out.println("4. Remove a record ID from list");

		System.out.println("5. Save records to a file");

		System.out.println("6. Load records from a file");

		System.out.println("7. Exit the program");
	}

	public void startMenu() {

		while (true) {

			printMenu();

			handleInput();
		}
	}

	private void handleInput() {

        	int selection = 0;

        	try {

            		selection = in.nextInt();
            		
        	} catch (InputMismatchException e) {

            		in.nextLine();

            		System.out.println("Invalid Input. Please try again");

            		return;
       	 	}

		in.nextLine();

		switch (selection) {

		case 1:

			this.listRecords();

			break;

		case 2:

			this.viewSpecificRecord();

			break;

		case 3:

			this.addRecord();

			break;

		case 4:

			this.removeRecord();

			break;

		case 5:

			this.saveToFile();

			break;

		case 6:

			this.loadFromFile();

			break;

		case 7:

			System.exit(0);

			break;

		default:

			System.out.println("Invalid input (");

			break;
		}

	}

	private void listRecords() {

		records.listRecords();
	}

	private void viewSpecificRecord() {

		System.out.print("Please enter the record ID ");

        	int id = 0;

        	try {
            		id = in.nextInt();

        	} catch (InputMismatchException e) {

            		in.nextLine();

            		System.out.println("Please enter an ID only [ ]");

            		return;
       	 	}

		in.nextLine();

		if (!records.exists(id)) {

			System.out.println("Sorry the record ID doesn't exist");

			return;
		}

		Record temp = records.viewRecord(id);

		System.out.println(temp.grabName() + "'s Record");

		System.out.println("-------------------------------------");

		System.out.println("Birthday " + temp.grabBirthday());

		System.out.println("Website " + temp.grabWebsite());

		System.out.println("Email " + temp.grabEmail());

		System.out.println("Address " + temp.grabAddress());

		System.out.println("-------------------------------------");
	}

	private void addRecord() {

		String name, address, website, birthday, email;

		System.out.println("Adding to record ");

		System.out.println("-------------------------");

		System.out.print("Name ");

		name = in.nextLine();

		System.out.print("Address ");

		address = in.nextLine();

		System.out.print("Website ");

		website = in.nextLine();

		System.out.print("Birthday ");

		birthday = in.nextLine();

		System.out.print("Email ");

		email = in.nextLine();

		records.add(new Record(name, address, website, email, birthday));
	}

	private void removeRecord() {

		System.out.print("Please enter the record ID ");

        	int id = 0;

        	try {

            		id = in.nextInt();

        	} catch (InputMismatchException e) {

            		in.nextLine();

            		System.out.println("Please enter an ID only");

            		return;
       	 	}

		in.nextLine();	

		if (!records.exists(id)) {

			System.out.println("Sorry that record doesn't exist");

			return;
		}

		records.remove(id);

		System.out.println("The record at ID: " + id + "has been deleted");
		System.out.println(" ");
	}

	private void saveToFile() {

		System.out.println("Please enter the in save path");

		String filePath = in.nextLine();

		try {

			File file = new File(filePath);

			if (!file.exists())

				file.createNewFile();

			Record[] data = records.grabRecords();

			FileOutputStream fout = new FileOutputStream(file);

			ObjectOutputStream objectOut = new ObjectOutputStream(fout);

			objectOut.writeObject(data);

			objectOut.flush();

			objectOut.close();

		} 
		catch (IOException e) {

			System.out.println("Sorry a error has occurred while writing to the file " + e.getMessage());
		}
	}

	private void loadFromFile() {

		System.out.println("Please enter in the save path ");

		String filePath = in.nextLine();

		try {

			File file = new File(filePath);

			if (!file.exists())

				file.createNewFile();

			FileInputStream fin = new FileInputStream(file);

			ObjectInputStream objectIn = new ObjectInputStream(fin);

			Record[] data = (Record[]) objectIn.readObject();

			for (Record r : data) {

				records.add(r);
			}

			System.out.println("All the records from the file have been loaded ");
			objectIn.close();

		}
		catch (IOException | ClassNotFoundException e) {

			System.out.println("Sorry a error has occurred while reading the file " + e.getMessage());
		
		}
	}
}