
// David Scott 
// 0337528@student.vvc.edu
// This program will let the user enter in the persons record that stores the user name, address, website, and birthday
// on to the record you can add and remove the records but also save and load them onto a file.
// chris was helping me on the final by giving me some pointers 

public class Main {

	public static void main(String[] args) {

		Menu menu = new Menu();

		menu.startMenu();
	}
}