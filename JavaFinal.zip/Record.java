import java.io.Serializable;

// Chris help me on on the Serializable 
public class Record implements Serializable {

	private static final long serialVersionUID = 1384785L;

	private String name, address, website, eMail, birthDay;


	public Record(String name, String address, String website, String eMail, String birthDay) {

		this.name = name;

		this.address = address;

		this.website = website;

		this.eMail = eMail;

		this.birthDay = birthDay;

	}

	public Record() {

		this.name = new String();

		this.address = new String();

		this.website = new String();

		this.eMail = new String();

		this.birthDay = new String();

	}

	public void setName(String name) {

		this.name = name;
	}

	public void setAddress(String address) {

		this.address = address;

	}

	public void setWebsite(String website) {

		this.website = website;
	}

	public void setEmail(String eMail) {

		this.eMail = eMail;
	}

	public void setBirthDay(String birthDay) {

		this.birthDay = birthDay;
	}

	public String grabName() {

		return name;
	}

	public String grabAddress() {

		return address;
	}

	public String grabWebsite() {

		return website;
	}

	public String grabEmail() {

		return eMail;
	}

	public String grabBirthday() {

		return birthDay;
	}
}
